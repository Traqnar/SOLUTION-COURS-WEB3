import { Context as childrenAndEventContext } from 'contexts/childrenAndEventContext';
import { useContext } from 'react';
import Children from 'components/List/children';

const ListOpinions = () => {
    const { sortedOpinions } = useContext(childrenAndEventContext);

    return sortedOpinions.map((child) => (
        <Children key={child.id} {...{ child }} />
    ));
};

export default ListOpinions;