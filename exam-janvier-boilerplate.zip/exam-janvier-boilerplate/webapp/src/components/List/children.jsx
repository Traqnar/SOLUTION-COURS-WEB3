import { Link } from 'react-router-dom';
const Children = ({ child }) => {
    return (
        <div>
            <Link to={`/children/${child.id}`}>{child.name}</Link>
        </div>
    );
};

export default Children;