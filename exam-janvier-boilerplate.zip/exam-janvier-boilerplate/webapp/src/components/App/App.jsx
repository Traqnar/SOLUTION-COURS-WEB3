import React, { Children } from 'react';
import { Routes, Route, useMatch, useNavigate } from 'react-router-dom';
import { Layout, Menu } from 'antd'
import ListChildren from 'components/List/listChildren';

const { Header, Content } = Layout



const App = () => {
  const navigate = useNavigate();

  return (
    <Layout className="layout">
    <Header>
      <Menu theme="dark" mode="horizontal" selectedKeys={[]}>
        <Menu.Item>Enfants</Menu.Item>
        <Menu.Item>Aide</Menu.Item>
      </Menu>
    </Header>
    <Content style={{ padding: '30px 50px' }}>
      <Menu />
        <Routes>
          <Route path="/help" element={<h1>HEEEELP</h1>} />
          <Route path="/children" element={<ListChildren/>} />
          <Route path="/children/:id" element={<h1>BATEAU</h1>} />
        </Routes>
      
    </Content>
    
  </Layout>

    

  )
}

export default App
