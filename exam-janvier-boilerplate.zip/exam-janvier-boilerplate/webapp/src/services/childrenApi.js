import axios from "axios"

const retrieveAll = () => {
    return axios.get("http://localhost:8080/api/children")
        .then(response => response.data)
}

const ChildrenApi = { retrieveAll};
export default ChildrenApi;