import axios from "axios"
const retrieveAll = () => {
    return axios.get("http://localhost:8080/api/volumes")
        .then(response => response.data)
}

const create = (newVolume) => {
    return axios.post("http://localhost:8080/api/volumes", newVolume)
        .then(response => response.data)
}

const remove = (resourceId) => {
    return axios.delete(`http://localhost:8080/api/volumes/${resourceId}`)
        .then(response => response.data)
}


export {
    retrieveAll,
    create,
    remove
}