import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { retrieveAll,create,remove } from '../services/eventsApi';
import  RetrieveAllEvent  from '../services/childrenApi';
const Context = React.createContext(null);

const ProviderWrapper = ({ children }) => {
    const [sortedChildren, setSortedChildren] = useState(retrieveAll);
    const [sortedEvent, setSortedEvent] = useState(RetrieveAllEvent.retrieveAll);

    const getChildWithEvents = (id) => {
        const newSortedChildren = [sortedChildren];
        const childrenToGet = newSortedChildren.find(
            (children) => children.id === id       // children.id is undefined probablement à cause de mongoDB ou que sais-je
        );
        if (!childrenToGet) return undefined;

    };

    const createOpinion = (opinion) => {
        const newSortedOpinions = sortedOpinions.concat({
            id: uuidv4(),
            text: opinion,
            score: 1,
        });

        newSortedOpinions.sort((a, b) => b.score - a.score);
        setSortedOpinions(newSortedOpinions);
    };

    const exposedValue = {
        sortedChildren,
        sortedEvent,
//      increaseOpinionScore,
        createOpinion,
    };

    return <Context.Provider value={exposedValue}>{children}</Context.Provider>;
};

export { Context, ProviderWrapper };