const mongoose = require("mongoose");
const ObjectId = require("mongoose/lib/schema/objectid");

// Define Schema
const eventsSchema = new mongoose.Schema({
    date: String,
    child: ObjectId,
    main: String,
});

eventsSchema.set("toJSON", {
    transform: (document, returnedObject) => {
        returnedObject.id = returnedObject._id.toString();
        delete returnedObject._id;
        delete returnedObject.__v;
    },
});

// Export model
module.exports = mongoose.model("Events", eventsSchema);
