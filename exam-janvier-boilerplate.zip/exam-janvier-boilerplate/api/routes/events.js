const router = require('express').Router()
const Events = require('../models/events')
// Find all
router.get("/", (req, res, next) => {
    Events.find({})
    .then(events => res.json(events))
    .catch(err => next(err))
})

// Find by ID
router.get("/:id", (req, res, next) => {
    Events.findById(req.params.id).then(event => {
    if (event) {
    res.json(event)
    } else {
    throw new NotFoundError()
    }
}).catch(err => next(err))
})

// Delete one
router.delete("/:id", (req, res, next) => {
Events.findByIdAndRemove(req.params.id).then(result => {
    if (result) {
    res.json(result)
    } else {
    throw new NotFoundError()
    }
})
    .catch(err => next(err))
});


// Insert one
router.post("/", (req, res, next) => {
const body = req.body
// Check body
const errorMessages = []
if (!body.name) errorMessages.push("naazeazme must be present")
if (!body.birthDate) errorMessages.push("aze must be present")
if (!body.gender) errorMessages.push("gender must be present")
if (errorMessages.length > 0) {
    res.status(422).json({ errorMessages })
    return
}
// Check existing
Events.find({ name: body.name }).then(event => {
    if (event && event.length > 0) {
    errorMessages.push("name must be unique")
    res.status(422).json({ errorMessages })
    } else {
    // Insert
    const event = new Events(body)
    event.save().then(result => {
        res.json(result)
    })
        .catch(err => next(err))
    }
})
    .catch(err => next(err))
})

module.exports = router